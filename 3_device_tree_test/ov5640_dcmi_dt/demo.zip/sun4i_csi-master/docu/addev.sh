modprobe $1
modprobe sun4i_csi0
