echo "making camera drivers...."
make M=drivers/media/video/sun4i_csi/device
make M=drivers/media/video/sun4i_csi/device modules_install

