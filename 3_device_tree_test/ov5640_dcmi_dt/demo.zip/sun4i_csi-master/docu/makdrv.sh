echo "making sun4i_csi0.ko...."
make M=drivers/media/video/sun4i_csi/csi0
make M=drivers/media/video/sun4i_csi/csi0 modules_install

