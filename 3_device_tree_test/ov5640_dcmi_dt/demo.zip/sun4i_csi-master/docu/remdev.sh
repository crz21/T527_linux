rmmod sun4i_csi0
rmmod $1
